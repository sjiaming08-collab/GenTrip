"""LLM scoring for candidate routes."""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from ..config import settings
from ..models.route import RoutePlan
from .client import get_llm_client
from .exceptions import LLMError

SYSTEM_PROMPT = """你是 GenTrip 路线评估器。
请对每条路线给出 execution、quality、preference 三个 0~1 分数和一句 comment。
execution 关注时间、预算、路线节奏；quality 关注 POI 质量和组合体验；preference 关注用户偏好匹配。
只输出 JSON：{"scores":[{"plan_id":"...","execution":0.0,"quality":0.0,"preference":0.0,"comment":"..."}]}。
"""


class LlmRouteScore(BaseModel):
    plan_id: str
    execution: float = Field(ge=0.0, le=1.0)
    quality: float = Field(ge=0.0, le=1.0)
    preference: float = Field(ge=0.0, le=1.0)
    comment: str = ""


class LlmRouteScoreResult(BaseModel):
    scores: list[LlmRouteScore] = Field(default_factory=list)


def _route_payload(route: RoutePlan) -> dict[str, Any]:
    return {
        "plan_id": route.plan_id,
        "plan_name": route.plan_name,
        "summary": route.summary,
        "total_duration_min": route.total_duration_min,
        "estimated_cost_per_person": route.estimated_cost_per_person,
        "stops": [
            {
                "name": stop.poi_name,
                "category": stop.category,
                "arrival_time": stop.arrival_time,
                "departure_time": stop.departure_time,
                "travel_time_from_prev_min": stop.travel_time_from_prev_min,
            }
            for stop in route.stops
        ],
    }


async def llm_score_routes(
    routes: list[RoutePlan],
    *,
    constraints: dict,
    user_query: str,
    memory_context: dict | None = None,
) -> dict[str, LlmRouteScore]:
    if not settings.llm_enabled or not settings.llm_api_key:
        return {}
    if not routes:
        return {}

    payload = {
        "user_query": user_query,
        "constraints": constraints,
        "memory_context": memory_context or {},
        "routes": [_route_payload(route) for route in routes],
    }
    try:
        raw = await get_llm_client().chat_json(
            SYSTEM_PROMPT,
            json.dumps(payload, ensure_ascii=False),
        )
        result = LlmRouteScoreResult.model_validate(raw)
    except (LLMError, ValidationError):
        return {}

    by_id: dict[str, LlmRouteScore] = {}
    for score in result.scores:
        by_id[score.plan_id] = score
    return by_id
