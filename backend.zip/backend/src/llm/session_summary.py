"""LLM-backed session summary with deterministic fallback."""

from __future__ import annotations

from typing import Any

from ..config import settings
from ..models.session import SessionState
from .client import get_llm_client
from .exceptions import LLMError, LLMParseError

SYSTEM_PROMPT = """你是 GenTrip 的对话记忆摘要器。
请把多轮路线规划对话压缩成一句中文摘要，保留区域、预算、时长、偏好、用户明确修改过的点。
只输出 JSON：{"dialog_summary": "一句话摘要"}。
"""


def fallback_dialog_summary(session: SessionState) -> str:
    turns = session.recent_turns[-3:]
    if not turns:
        return session.dialog_summary
    last = turns[-1]
    parts = [f"最近用户需求：{last.user_query}"]
    if session.assumptions:
        messages = [item.get("message") for item in session.assumptions[:3] if item.get("message")]
        if messages:
            parts.append("系统假设：" + "；".join(messages))
    if session.current_route:
        name = session.current_route.get("plan_name") or "当前路线"
        parts.append(f"当前路线：{name}")
    return "，".join(parts)


def _summary_payload(session: SessionState) -> dict[str, Any]:
    return {
        "previous_summary": session.dialog_summary,
        "current_route": session.current_route,
        "assumptions": session.assumptions,
        "recent_turns": [turn.model_dump(mode="json") for turn in session.recent_turns[-5:]],
    }


async def summarize_session(session: SessionState) -> str:
    if not settings.llm_enabled or not settings.llm_api_key:
        return fallback_dialog_summary(session)

    client = get_llm_client()
    try:
        raw = await client.chat_json(SYSTEM_PROMPT, str(_summary_payload(session)))
    except LLMError:
        return fallback_dialog_summary(session)

    summary = raw.get("dialog_summary")
    if not isinstance(summary, str) or not summary.strip():
        raise LLMParseError(f"会话摘要响应缺少 dialog_summary: {raw}")
    return summary.strip()
